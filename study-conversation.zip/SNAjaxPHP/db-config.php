<?php 
// $conf = array("mysql:host=148.72.232.169;dbname=study;charset=utf8","study2019","800815wj");
// $conf = array("mysql:host=localhost;dbname=study;charset=utf8","root","111111");
$conf = array("mysql:host=148.72.232.169:3306;dbname=s;charset=utf8","brucec","800815wj");