<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>课程编号：<?=$_GET['id'];?></title>
        <style type="text/css">
    p{
        margin-top:5;
        white-space:0; 
        font-family: arial;
        padding: 5px;
        width: auto;
        display: block;
        background: lightblue;
        word-wrap: break-word;
        border: 0px solid;
        border-radius: 5px;


    }
    .role{    
        margin-left: 2%;
        width: 100px;
        padding-right: 10px;
        outline: none;
        border: none;
        list-style: none;
        background: transparent;
        font-size: 20px;

    }


    .sts{
        
    }
    .qs{
        background: pink;

    }
    .qslist{
        background: lightgreen;
        margin-left: 20%;

    }
    .correct{
        background: green;
        margin-left: 30%;

    }
    .ccc{
        background: orange;
        margin-left: 20%;
        color:red;
    }
    #space{
    	width: 100%;
    	height: 100px;
    }


</style>
</head>
<body>

<?php
header('Content-type:text/html;charset=utf-8');
require('pdo.php');


//生成随机颜色函数
function randrgb() 
{ 
  $str='0123456789ABCDEF'; 
    $estr='#'; 
    $len=strlen($str); 
    for($i=1;$i<=6;$i++) 
    { 
        $num=rand(0,$len-1);   
        $estr=$estr.$str[$num];  
    } 
    return $estr; 
} 


$lessonId= intval($_GET['id']);

$stmt = $pdo->query("select * from conv where lesson=".$lessonId);
// var_dump($stmt);
$res=$stmt->fetchAll();
// echo '<pre>';

// print_r($res);//輸出結果數組;

$arr = $res[0];



echo '<p>课程编号:'.($arr['lesson']).'</p>';
echo '<p>笔记时间:'.($arr['notetime']).'</p>';
echo '<p>笔记花费时间:'.($arr['studytime']).'分钟</p>';

$content=$arr['notestr'];
// $obj = (unserialize($content));
// echo gettype($content);
$obj = json_decode($content);
// echo $obj;

echo '<p>课程主题:'. $obj->subject .'</p>';
// echo '问题列表:'.$obj->questionArr;
// echo '句型列表:'.$obj->sentencesArr;

// var_dump($arr['notestr']);//　輸出字符串
// $arr = '['+$arr['notestr']+']';

$sentences =count($obj->sentencesArr);
echo '<p>例句数：'.$sentences.'</p>';
echo '<p>角色数：'.$obj->roleNum.'个人对话</p>';
$colorArr  = array();
// // 根据角色数自动生成颜色数组
// for($c = 0;$c<$obj->roleNum;$c++){
//     array_push($colorArr, randrgb());
// }

$colorArr = array('SpringGreen','LightSkyBlue','LightPink','Plum','Gold','Coral');

// var_dump($colorArr);
echo '<hr>';
for($i=0;$i<$sentences;$i++){
    $color = $colorArr[$i%$obj->roleNum];
    echo '<h3><p style = "background:'.$color.'"><input type = "text" class = "role" value = '.($obj->sentencesArr[$i][0]).':>';
    // echo '<h3 ><p style = "background:'.$color.'"><span class = "role">'.$obj->sentencesArr[$i][0].':</span>';

    echo '<span>'.($obj->sentencesArr[$i][1]).'</span></p></h3>';

};

//*********************首字母大写***************
// for($i=0;$i<$sentences;$i++){
//     $color = $colorArr[$i%$obj->roleNum];
//     echo '<h3><p style = "background:'.$color.'"><input type = "text" class = "role" value = '.ucfirst($obj->sentencesArr[$i][0]).':>';
//     // echo '<h3 ><p style = "background:'.$color.'"><span class = "role">'.$obj->sentencesArr[$i][0].':</span>';

//     echo '<span>'.ucfirst($obj->sentencesArr[$i][1]).'</span></p></h3>';

// };
//*********************首字母大写 End***************



?>
<div id='space'></div>
</body>
</html>
